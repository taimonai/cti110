''' Type your code here. '''
def calculate_cost(cost_of_gas: float, miles_per_gallon: float, miles_predicted_to_travel: int):
    return f"{cost_of_gas / miles_per_gallon * miles_predicted_to_travel:.2f}"


if __name__ == '__main__':
    miles_per_gallon = float(input())
    cost_of_gas = float(input())

    print(f"{calculate_cost(cost_of_gas, miles_per_gallon, 20)} {calculate_cost(cost_of_gas, miles_per_gallon, 75)} {calculate_cost(cost_of_gas, miles_per_gallon, 500)}")